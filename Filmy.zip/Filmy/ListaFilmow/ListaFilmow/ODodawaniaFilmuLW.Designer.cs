﻿
namespace ListaFilmow
{
    partial class ODodawaniaFilmuLW
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ODodawaniaFilmuLW));
            this.mtxtCzasTrawania = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbGatunek = new System.Windows.Forms.ComboBox();
            this.mtxtRokWydania = new System.Windows.Forms.MaskedTextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.txtAktor = new System.Windows.Forms.TextBox();
            this.txtRezyser = new System.Windows.Forms.TextBox();
            this.txtTytul = new System.Windows.Forms.TextBox();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnDodajFilm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mtxtCzasTrawania
            // 
            this.mtxtCzasTrawania.Location = new System.Drawing.Point(150, 295);
            this.mtxtCzasTrawania.Mask = "90:00";
            this.mtxtCzasTrawania.Name = "mtxtCzasTrawania";
            this.mtxtCzasTrawania.Size = new System.Drawing.Size(570, 20);
            this.mtxtCzasTrawania.TabIndex = 32;
            this.mtxtCzasTrawania.ValidatingType = typeof(System.DateTime);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(52, 298);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 31;
            this.label1.Text = "Czas trwania";
            // 
            // cmbGatunek
            // 
            this.cmbGatunek.FormattingEnabled = true;
            this.cmbGatunek.Items.AddRange(new object[] {
            "Horror",
            "Dramat",
            "Komedia",
            "Fantazy",
            "Przygodowa",
            "Romans",
            "Dokumentalny"});
            this.cmbGatunek.Location = new System.Drawing.Point(150, 178);
            this.cmbGatunek.Name = "cmbGatunek";
            this.cmbGatunek.Size = new System.Drawing.Size(570, 21);
            this.cmbGatunek.TabIndex = 44;
            // 
            // mtxtRokWydania
            // 
            this.mtxtRokWydania.Location = new System.Drawing.Point(150, 220);
            this.mtxtRokWydania.Mask = "00/00/0000";
            this.mtxtRokWydania.Name = "mtxtRokWydania";
            this.mtxtRokWydania.Size = new System.Drawing.Size(570, 20);
            this.mtxtRokWydania.TabIndex = 43;
            this.mtxtRokWydania.ValidatingType = typeof(System.DateTime);
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(150, 262);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(570, 20);
            this.txtOpis.TabIndex = 42;
            // 
            // txtAktor
            // 
            this.txtAktor.Location = new System.Drawing.Point(150, 143);
            this.txtAktor.Name = "txtAktor";
            this.txtAktor.Size = new System.Drawing.Size(570, 20);
            this.txtAktor.TabIndex = 41;
            // 
            // txtRezyser
            // 
            this.txtRezyser.Location = new System.Drawing.Point(150, 108);
            this.txtRezyser.Name = "txtRezyser";
            this.txtRezyser.Size = new System.Drawing.Size(570, 20);
            this.txtRezyser.TabIndex = 40;
            // 
            // txtTytul
            // 
            this.txtTytul.Location = new System.Drawing.Point(150, 67);
            this.txtTytul.Name = "txtTytul";
            this.txtTytul.Size = new System.Drawing.Size(570, 20);
            this.txtTytul.TabIndex = 39;
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l6.Location = new System.Drawing.Point(94, 265);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(37, 17);
            this.l6.TabIndex = 38;
            this.l6.Text = "Opis";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l5.Location = new System.Drawing.Point(38, 220);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(93, 17);
            this.l5.TabIndex = 37;
            this.l5.Text = "Data wydania";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l4.Location = new System.Drawing.Point(29, 182);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(111, 17);
            this.l4.TabIndex = 36;
            this.l4.Text = "Gatunek filmowy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(92, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 17);
            this.label4.TabIndex = 35;
            this.label4.Text = "Tytuł";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l1.Location = new System.Drawing.Point(71, 111);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(60, 17);
            this.l1.TabIndex = 34;
            this.l1.Text = "Reżyser";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l2.Location = new System.Drawing.Point(90, 146);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(41, 17);
            this.l2.TabIndex = 33;
            this.l2.Text = "Aktor";
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(474, 362);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(267, 42);
            this.btnZamknij.TabIndex = 46;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnDodajFilm
            // 
            this.btnDodajFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDodajFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilm.Location = new System.Drawing.Point(32, 362);
            this.btnDodajFilm.Name = "btnDodajFilm";
            this.btnDodajFilm.Size = new System.Drawing.Size(267, 42);
            this.btnDodajFilm.TabIndex = 45;
            this.btnDodajFilm.Text = "Dodaj  film";
            this.btnDodajFilm.UseVisualStyleBackColor = false;
            this.btnDodajFilm.Click += new System.EventHandler(this.btnDodajFilm_Click);
            // 
            // ODodawaniaFilmuLW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 427);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnDodajFilm);
            this.Controls.Add(this.cmbGatunek);
            this.Controls.Add(this.mtxtRokWydania);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtAktor);
            this.Controls.Add(this.txtRezyser);
            this.Controls.Add(this.txtTytul);
            this.Controls.Add(this.l6);
            this.Controls.Add(this.l5);
            this.Controls.Add(this.l4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.mtxtCzasTrawania);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(816, 466);
            this.MinimumSize = new System.Drawing.Size(816, 466);
            this.Name = "ODodawaniaFilmuLW";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Okno Dodawania Filmu do bazy";
            this.Load += new System.EventHandler(this.ODodawaniaFilmuLW_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MaskedTextBox mtxtCzasTrawania;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbGatunek;
        private System.Windows.Forms.MaskedTextBox mtxtRokWydania;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.TextBox txtAktor;
        private System.Windows.Forms.TextBox txtRezyser;
        private System.Windows.Forms.TextBox txtTytul;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnDodajFilm;
    }
}