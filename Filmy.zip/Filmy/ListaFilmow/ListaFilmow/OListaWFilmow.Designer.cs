﻿
namespace ListaFilmow
{
    partial class OListaWFilmow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OListaWFilmow));
            this.label1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l6 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnWyswietl = new System.Windows.Forms.Button();
            this.btnDodajFilm = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.btnUsunFilm = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.txtTytul = new System.Windows.Forms.TextBox();
            this.txtRezyser = new System.Windows.Forms.TextBox();
            this.txtAktor = new System.Windows.Forms.TextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.mtxtRokWydania = new System.Windows.Forms.MaskedTextBox();
            this.cmbGatunek = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label1.Location = new System.Drawing.Point(39, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wyszukaj po:";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l2.Location = new System.Drawing.Point(91, 158);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(41, 17);
            this.l2.TabIndex = 1;
            this.l2.Text = "Aktor";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l1.Location = new System.Drawing.Point(72, 117);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(60, 17);
            this.l1.TabIndex = 2;
            this.l1.Text = "Reżyser";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(91, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tytuł";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l4.Location = new System.Drawing.Point(29, 189);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(111, 17);
            this.l4.TabIndex = 4;
            this.l4.Text = "Gatunek filmowy";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l5.Location = new System.Drawing.Point(41, 231);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(93, 17);
            this.l5.TabIndex = 5;
            this.l5.Text = "Data wydania";
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l6.Location = new System.Drawing.Point(95, 268);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(37, 17);
            this.l6.TabIndex = 6;
            this.l6.Text = "Opis";
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.listView1.Location = new System.Drawing.Point(13, 346);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(775, 207);
            this.listView1.TabIndex = 7;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // btnWyswietl
            // 
            this.btnWyswietl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnWyswietl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnWyswietl.Location = new System.Drawing.Point(12, 303);
            this.btnWyswietl.Name = "btnWyswietl";
            this.btnWyswietl.Size = new System.Drawing.Size(777, 36);
            this.btnWyswietl.TabIndex = 8;
            this.btnWyswietl.Text = "Wyświetl wyniki";
            this.btnWyswietl.UseVisualStyleBackColor = false;
            this.btnWyswietl.Click += new System.EventHandler(this.btnWyswietl_Click);
            // 
            // btnDodajFilm
            // 
            this.btnDodajFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDodajFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilm.Location = new System.Drawing.Point(14, 582);
            this.btnDodajFilm.Name = "btnDodajFilm";
            this.btnDodajFilm.Size = new System.Drawing.Size(165, 47);
            this.btnDodajFilm.TabIndex = 9;
            this.btnDodajFilm.Text = "Dodaj nowy film";
            this.btnDodajFilm.UseVisualStyleBackColor = false;
            this.btnDodajFilm.Click += new System.EventHandler(this.btnDodajFilm_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(221, 582);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(165, 47);
            this.btnModyfikujFilm.TabIndex = 10;
            this.btnModyfikujFilm.Text = "Modyfikuj film";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // btnUsunFilm
            // 
            this.btnUsunFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnUsunFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnUsunFilm.Location = new System.Drawing.Point(420, 582);
            this.btnUsunFilm.Name = "btnUsunFilm";
            this.btnUsunFilm.Size = new System.Drawing.Size(165, 47);
            this.btnUsunFilm.TabIndex = 11;
            this.btnUsunFilm.Text = "Usuń film";
            this.btnUsunFilm.UseVisualStyleBackColor = false;
            this.btnUsunFilm.Click += new System.EventHandler(this.btnUsunFilm_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(623, 582);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(165, 47);
            this.btnZamknij.TabIndex = 12;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // txtTytul
            // 
            this.txtTytul.Location = new System.Drawing.Point(146, 80);
            this.txtTytul.Name = "txtTytul";
            this.txtTytul.Size = new System.Drawing.Size(591, 20);
            this.txtTytul.TabIndex = 13;
            // 
            // txtRezyser
            // 
            this.txtRezyser.Location = new System.Drawing.Point(146, 117);
            this.txtRezyser.Name = "txtRezyser";
            this.txtRezyser.Size = new System.Drawing.Size(591, 20);
            this.txtRezyser.TabIndex = 14;
            // 
            // txtAktor
            // 
            this.txtAktor.Location = new System.Drawing.Point(146, 155);
            this.txtAktor.Name = "txtAktor";
            this.txtAktor.Size = new System.Drawing.Size(591, 20);
            this.txtAktor.TabIndex = 15;
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(146, 268);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(591, 20);
            this.txtOpis.TabIndex = 16;
            // 
            // mtxtRokWydania
            // 
            this.mtxtRokWydania.Location = new System.Drawing.Point(146, 231);
            this.mtxtRokWydania.Mask = "00/00/0000";
            this.mtxtRokWydania.Name = "mtxtRokWydania";
            this.mtxtRokWydania.Size = new System.Drawing.Size(591, 20);
            this.mtxtRokWydania.TabIndex = 17;
            this.mtxtRokWydania.ValidatingType = typeof(System.DateTime);
            // 
            // cmbGatunek
            // 
            this.cmbGatunek.FormattingEnabled = true;
            this.cmbGatunek.Items.AddRange(new object[] {
            "Horror",
            "Dramat",
            "Komedia",
            "Fantazy",
            "Przygodowa",
            "Romans",
            "Dokumentalny"});
            this.cmbGatunek.Location = new System.Drawing.Point(146, 189);
            this.cmbGatunek.Name = "cmbGatunek";
            this.cmbGatunek.Size = new System.Drawing.Size(591, 21);
            this.cmbGatunek.TabIndex = 18;
            // 
            // OListaWFilmow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 649);
            this.Controls.Add(this.cmbGatunek);
            this.Controls.Add(this.mtxtRokWydania);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtAktor);
            this.Controls.Add(this.txtRezyser);
            this.Controls.Add(this.txtTytul);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnUsunFilm);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.btnDodajFilm);
            this.Controls.Add(this.btnWyswietl);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.l6);
            this.Controls.Add(this.l5);
            this.Controls.Add(this.l4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OListaWFilmow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista fimow";
            this.Load += new System.EventHandler(this.OListaWFilmow_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnWyswietl;
        private System.Windows.Forms.Button btnDodajFilm;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.Button btnUsunFilm;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.TextBox txtTytul;
        private System.Windows.Forms.TextBox txtRezyser;
        private System.Windows.Forms.TextBox txtAktor;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.MaskedTextBox mtxtRokWydania;
        private System.Windows.Forms.ComboBox cmbGatunek;
    }
}