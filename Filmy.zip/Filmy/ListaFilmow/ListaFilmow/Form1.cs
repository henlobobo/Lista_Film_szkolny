﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWszysktichFilmow_Click(object sender, EventArgs e)
        {
            Form okno = new OListaWFilmow();
            okno.Show();
            
        }

        private void btnListaFilmowDObejrzenia_Click(object sender, EventArgs e)
        {
            Form okno = new OListyDoObejrzenia();
            okno.Show();
            
        }

        private void ListaFilmowObejrzanych_Click(object sender, EventArgs e)
        {
            Form okno = new OFilmowO();
            okno.Show();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
