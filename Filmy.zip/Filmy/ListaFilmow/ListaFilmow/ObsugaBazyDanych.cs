﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Data;
using System.Windows.Forms;

namespace ListaFilmow
{
    public class ObsugaBazyDanych
    {

        public SQLiteCommand cmd = BazaDanych.polaczenie.CreateCommand();
        public int iloscRecordow(string nazwaTabeli = "WszystkieFilmy")
        {
            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT MAX(id) FROM [{nazwaTabeli}]";
            var countResult = cmd.ExecuteScalar();
            int count = countResult is System.DBNull ? 0 : (int)(long)countResult;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return count + 1;
        }
        public bool CzyIstniej(string tytul, string rezyser)
        {
            bool czyIstniej;
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT COUNT(Id) FROM  [WszystkieFilmy] WHERE Tytul ='" + tytul + "' AND Rezyser = '" + rezyser + "'";
            var countResult = cmd.ExecuteScalar();
            if ((int)(long)countResult != 0)
            {
                //istnieje taki film
                czyIstniej = true;
            }
            else
            {
                czyIstniej = false;
            }
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return czyIstniej;
        }
        public void ModyfikacjaTabeli(string pole, int id, string nazwaPola, string nazwaTabeli = "WszystkieFilmy")
        {

            BazaDanych.polaczenie.Open();
            //     var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"UPDATE [{nazwaTabeli}] SET {nazwaPola} = '" + pole + "' WHERE Id=" + id;
            cmd.ExecuteNonQuery();


            BazaDanych.polaczenie.Close();


        }
        public void CoModyfikowac(string tytul, string rezyser, string aktor, string gatunek, string opis, string dataWydania, string czasTrwania, int id, string nazwaTabeli = "WszystkieFilmy")
        {
            string Tytul = tytul;
            string Rezyser = rezyser;
            string Aktor = aktor;
            string Gatunek = gatunek;
            string Opis = opis;
            string DataWydania = dataWydania;
            string CzasTrwania = czasTrwania;
            if (Tytul != "")
            {
                ModyfikacjaTabeli(tytul, id, "Tytul", nazwaTabeli);
            }
            if (Rezyser != "")
            {
                ModyfikacjaTabeli(Rezyser, id, "Rezyser", nazwaTabeli);

            }
            if (Aktor != "")
            {
                ModyfikacjaTabeli(Aktor, id, "RolaGlowna", nazwaTabeli);

            }
            if (Gatunek != "")
            {
                ModyfikacjaTabeli(Rezyser, id, "Rezyser", nazwaTabeli);

            }
            if (Opis != "")
            {
                ModyfikacjaTabeli(Opis, id, "OpisFabuly", nazwaTabeli);

            }
            if (DataWydania != "  .  .")
            {
                ModyfikacjaTabeli(DataWydania, id, "DataWydania", nazwaTabeli);

            }
            if (czasTrwania != "")
            {
                ModyfikacjaTabeli(czasTrwania, id, "CzasTrwania", nazwaTabeli);

            }


        }
        public int DoadnieRestauracji(string tytul, string rezyser, string aktor, string gatunek, string opis, string dataWydania, string czasTrwania, string nazwaTabeli = "WszystkieFilmy")
        {
            string Tytul = tytul;
            string Rezyser = rezyser;
            string Aktor = aktor;
            string Gatunek = gatunek;
            string Opis = opis;
            string DataWydania = dataWydania;
            string CzasTrwania = czasTrwania;
            int id = iloscRecordow(nazwaTabeli);

            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"INSERT INTO [{nazwaTabeli}] (Id,Tytul,Rezyser,RolaGlowna,GatunekFilmowy,OpisFabuly,DataWydania,CzasTrwania) VALUES" +
                $" ({id}, '{Tytul}', '{Rezyser}', '{Aktor}', '{Gatunek}', '{Opis}', '{DataWydania}', '{czasTrwania}')";
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return id;

        }
        public string WyszukiwaniePoParametrach(string tytul, string rezyser, string aktor, string gatunek, string opis, string dataWydania)
        {
            string Tytul = tytul;
            string Rezyser = rezyser;
            string Aktor = aktor;
            string Gatunek = gatunek;
            string Opis = opis;
            string DataWydania = dataWydania;
        //    MessageBox.Show(dataWydania);

            string zapytanie = "WHERE ";
            if (Tytul != "")
            {
                zapytanie += "Tytul LIKE '%" + Tytul + "%' AND ";
            }
            if (Rezyser != "")
            {
                zapytanie += "Rezyser LIKE '%" + Rezyser + "%' AND ";
            }
            if (Aktor != "")
            {
                zapytanie += "RolaGlowna LIKE '%" + Aktor + "%' AND ";
            }
            if (Gatunek != "")
            {
                zapytanie += "GatunekFilmowy = '" + Gatunek + "' AND ";
            }
            if (Opis != "")
            {
                zapytanie += "OpisFabuly LIKE '%" + Opis + "%' AND ";
            }
            if (DataWydania != "  .  .")
            {
                zapytanie += "DataWydania LIKE '%" + DataWydania + "%' AND ";
            }


            if (zapytanie == "WHERE ")
            {
                zapytanie = " AND";
            }
            int pocztek = (int)(zapytanie.Length) - 4;

            zapytanie = zapytanie.Remove(pocztek, 3);
            return zapytanie;

        }

        public string ZapytaniaUsuwania(int id)
        {
            string zapytania = $" WHERE Id=" + id;
            return zapytania;
        }
        public void Usuwanie(int id, string nazwaTabeli = "WszystkieFilmy")
        {
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"DELETE FROM  [{nazwaTabeli}] WHERE Id =" + id;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();

        }

        public void WyswietlanieTabeli(string zapytanie, string tabela = "WszystkieFilmy", ListView lista = null)
        {

            lista.Clear();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT * FROM [{tabela}]  " + zapytanie;

            using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lista.View = View.Details;


                lista.Columns.Add("Id");
                lista.Columns.Add("Tytul                ");
                lista.Columns.Add("Rezyser              ");
                lista.Columns.Add("Rola Glowna          ");
                lista.Columns.Add("Gatunek Filmowy    ");
                lista.Columns.Add("Data Wydania");
                lista.Columns.Add("Opis Fabuly                                              ");
                lista.Columns.Add("Czas Trwania");

                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);

                foreach (DataRow row in dt.Rows)
                {

                    ListViewItem item1 = new ListViewItem(row["Id"].ToString());
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["Tytul"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["Rezyser"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["RolaGlowna"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["GatunekFilmowy"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["DataWydania"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["OpisFabuly"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row["CzasTrwania"].ToString()));

                    lista.Items.Add(item1);


                }
            }


        }
    }

}
