﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OListaWFilmow : Form
    {
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public OListaWFilmow()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            Form okno = new ODodawaniaFilmuLW();
            okno.Show();
            this.Close();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnWyswietl_Click(object sender, EventArgs e)
        {
            string Tytul = txtTytul.Text;
            string Rezyser = txtRezyser.Text;
            string Aktor = txtAktor.Text;
            string Gatunek = cmbGatunek.Text;
            string Opis = txtOpis.Text;
            string DataWydania = mtxtRokWydania.Text;
           

            string zapytanie = obsugaBazyDanych.WyszukiwaniePoParametrach(Tytul, Rezyser, Aktor, Gatunek, Opis, DataWydania);
          obsugaBazyDanych.WyswietlanieTabeli(zapytanie, "WszystkieFilmy",listView1);



        }
        

        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            Form okno = new OModyfikacjiFilmow();
            okno.Show();
            this.Close();
        }

        private void btnUsunFilm_Click(object sender, EventArgs e)
        {
            Form okno = new OUsuwaniaFilmowW();
            okno.Show();
            this.Close();
        }

        private void OListaWFilmow_Load(object sender, EventArgs e)
        {
            obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
        }
    }
}
 
