﻿
namespace ListaFilmow
{
    partial class OFilmowO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OFilmowO));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbOcena = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbGatunek = new System.Windows.Forms.ComboBox();
            this.mtxtRokWydania = new System.Windows.Forms.MaskedTextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.txtAktor = new System.Windows.Forms.TextBox();
            this.txtRezyser = new System.Windows.Forms.TextBox();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnUsunFilm = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.btnDodajFilm = new System.Windows.Forms.Button();
            this.btnWyswietl = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.txtOpinia = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(215, 9);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(570, 20);
            this.textBox1.TabIndex = 62;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(167, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 61;
            this.label3.Text = "Tytuł";
            // 
            // cmbOcena
            // 
            this.cmbOcena.AllowDrop = true;
            this.cmbOcena.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.cmbOcena.FormattingEnabled = true;
            this.cmbOcena.Items.AddRange(new object[] {
            "Rosnąco",
            "Malejąco"});
            this.cmbOcena.Location = new System.Drawing.Point(215, 266);
            this.cmbOcena.Name = "cmbOcena";
            this.cmbOcena.Size = new System.Drawing.Size(253, 25);
            this.cmbOcena.TabIndex = 60;
            this.cmbOcena.Text = "Rosnąco";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(74, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 17);
            this.label2.TabIndex = 59;
            this.label2.Text = "Sortuj według oceny";
            // 
            // cmbGatunek
            // 
            this.cmbGatunek.FormattingEnabled = true;
            this.cmbGatunek.Items.AddRange(new object[] {
            "Horror",
            "Dramat",
            "Komedia",
            "Fantazy",
            "Przygodowa",
            "Romans",
            "Dokumentalny"});
            this.cmbGatunek.Location = new System.Drawing.Point(215, 119);
            this.cmbGatunek.Name = "cmbGatunek";
            this.cmbGatunek.Size = new System.Drawing.Size(570, 21);
            this.cmbGatunek.TabIndex = 58;
            // 
            // mtxtRokWydania
            // 
            this.mtxtRokWydania.Location = new System.Drawing.Point(215, 155);
            this.mtxtRokWydania.Mask = "00/00/0000";
            this.mtxtRokWydania.Name = "mtxtRokWydania";
            this.mtxtRokWydania.Size = new System.Drawing.Size(570, 20);
            this.mtxtRokWydania.TabIndex = 57;
            this.mtxtRokWydania.ValidatingType = typeof(System.DateTime);
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(215, 197);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(570, 20);
            this.txtOpis.TabIndex = 56;
            // 
            // txtAktor
            // 
            this.txtAktor.Location = new System.Drawing.Point(215, 82);
            this.txtAktor.Name = "txtAktor";
            this.txtAktor.Size = new System.Drawing.Size(570, 20);
            this.txtAktor.TabIndex = 55;
            // 
            // txtRezyser
            // 
            this.txtRezyser.Location = new System.Drawing.Point(215, 46);
            this.txtRezyser.Name = "txtRezyser";
            this.txtRezyser.Size = new System.Drawing.Size(570, 20);
            this.txtRezyser.TabIndex = 54;
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(695, 575);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(165, 43);
            this.btnZamknij.TabIndex = 53;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnUsunFilm
            // 
            this.btnUsunFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnUsunFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnUsunFilm.Location = new System.Drawing.Point(492, 575);
            this.btnUsunFilm.Name = "btnUsunFilm";
            this.btnUsunFilm.Size = new System.Drawing.Size(165, 43);
            this.btnUsunFilm.TabIndex = 52;
            this.btnUsunFilm.Text = "Usuń film";
            this.btnUsunFilm.UseVisualStyleBackColor = false;
            this.btnUsunFilm.Click += new System.EventHandler(this.btnUsunFilm_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(293, 575);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(165, 43);
            this.btnModyfikujFilm.TabIndex = 51;
            this.btnModyfikujFilm.Text = "Modyfikuj film";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // btnDodajFilm
            // 
            this.btnDodajFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDodajFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilm.Location = new System.Drawing.Point(86, 575);
            this.btnDodajFilm.Name = "btnDodajFilm";
            this.btnDodajFilm.Size = new System.Drawing.Size(165, 43);
            this.btnDodajFilm.TabIndex = 50;
            this.btnDodajFilm.Text = "Dodaj nowy film";
            this.btnDodajFilm.UseVisualStyleBackColor = false;
            this.btnDodajFilm.Click += new System.EventHandler(this.btnDodajFilm_Click);
            // 
            // btnWyswietl
            // 
            this.btnWyswietl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnWyswietl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnWyswietl.Location = new System.Drawing.Point(84, 296);
            this.btnWyswietl.Name = "btnWyswietl";
            this.btnWyswietl.Size = new System.Drawing.Size(777, 36);
            this.btnWyswietl.TabIndex = 49;
            this.btnWyswietl.Text = "Wyświetl wyniki";
            this.btnWyswietl.UseVisualStyleBackColor = false;
            this.btnWyswietl.Click += new System.EventHandler(this.btnWyswietl_Click);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.listView1.Location = new System.Drawing.Point(85, 339);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(775, 207);
            this.listView1.TabIndex = 48;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l6.Location = new System.Drawing.Point(162, 204);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(37, 17);
            this.l6.TabIndex = 47;
            this.l6.Text = "Opis";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l5.Location = new System.Drawing.Point(113, 158);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(93, 17);
            this.l5.TabIndex = 46;
            this.l5.Text = "Data wydania";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l4.Location = new System.Drawing.Point(98, 123);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(111, 17);
            this.l4.TabIndex = 45;
            this.l4.Text = "Gatunek filmowy";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l1.Location = new System.Drawing.Point(146, 46);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(60, 17);
            this.l1.TabIndex = 44;
            this.l1.Text = "Reżyser";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l2.Location = new System.Drawing.Point(157, 82);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(41, 17);
            this.l2.TabIndex = 43;
            this.l2.Text = "Aktor";
            // 
            // txtOpinia
            // 
            this.txtOpinia.Location = new System.Drawing.Point(215, 239);
            this.txtOpinia.Name = "txtOpinia";
            this.txtOpinia.Size = new System.Drawing.Size(570, 20);
            this.txtOpinia.TabIndex = 64;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(157, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 63;
            this.label1.Text = "Opinia";
            // 
            // OFilmowO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(973, 648);
            this.Controls.Add(this.txtOpinia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbOcena);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbGatunek);
            this.Controls.Add(this.mtxtRokWydania);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtAktor);
            this.Controls.Add(this.txtRezyser);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnUsunFilm);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.btnDodajFilm);
            this.Controls.Add(this.btnWyswietl);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.l6);
            this.Controls.Add(this.l5);
            this.Controls.Add(this.l4);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(989, 687);
            this.MinimumSize = new System.Drawing.Size(989, 687);
            this.Name = "OFilmowO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Okno listy wszystkich filmów";
            this.Load += new System.EventHandler(this.OFilmowO_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbOcena;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbGatunek;
        private System.Windows.Forms.MaskedTextBox mtxtRokWydania;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.TextBox txtAktor;
        private System.Windows.Forms.TextBox txtRezyser;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnUsunFilm;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.Button btnDodajFilm;
        private System.Windows.Forms.Button btnWyswietl;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.TextBox txtOpinia;
        private System.Windows.Forms.Label label1;
    }
}