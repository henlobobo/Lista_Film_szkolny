﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Data;
using System.Windows.Forms;

namespace ListaFilmow
{
   public class ObslugaBazyDanychDO
    {
        public SQLiteCommand cmd = BazaDanych.polaczenie.CreateCommand();
        public int iloscRecordow(string nazwaTabeli)
        {
            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT MAX(id) FROM [{nazwaTabeli}]";
            var countResult = cmd.ExecuteScalar();
            int count = countResult is System.DBNull ? 0 : (int)(long)countResult;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return count + 1;
        }
        public bool CzyIstniej(int IdNFilmu)
        {
            bool czyIstniej;
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT COUNT(Id) FROM  [FilmyDoObejrzenia] WHERE IdFilmuDoObejrzenia =" + IdNFilmu;
            var countResult = cmd.ExecuteScalar();
            if ((int)(long)countResult != 0)
            {
                //istnieje taki film
                czyIstniej = true;
            }
            else
            {
                czyIstniej = false;
            }
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return czyIstniej;
        }
        public void ModyfikacjaTabeli(string pole, int id, string nazwaPola, string nazwaTabeli = "FilmyDoObejrzenia")
        {

            BazaDanych.polaczenie.Open();
            //     var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"UPDATE [{nazwaTabeli}] SET {nazwaPola} = '" + pole + "' WHERE Id=" + id;
            cmd.ExecuteNonQuery();


            BazaDanych.polaczenie.Close();


        }
       
        public int DoadnieFilmu(int IdFilmuDoObejrznia, int checObejrzenia, string nazwaTabeli = "FilmyDoObejrzenia")
        {

            int id = iloscRecordow(nazwaTabeli);

            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"INSERT INTO [{nazwaTabeli}] (Id,IdFilmuDoObejrzenia,ChecObejrzenia) VALUES" +
                $" ({id},{IdFilmuDoObejrznia}, '{checObejrzenia}')";
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return id;

        }
        public string WyszukiwaniePoParametrach(string tytul, string rezyser, string aktor, string gatunek, string opis, string dataWydania, string sortuj,string tabela,string tabela1)
        {
            string Tytul = tytul;
            string Rezyser = rezyser;
            string Aktor = aktor;
            string Gatunek = gatunek;
            string Opis = opis;
            string DataWydania = dataWydania;

            string zapytanie = "WHERE ";
            if (Tytul != "")
            {
                zapytanie += $"{tabela}.Tytul LIKE '%" + Tytul + "%' AND ";
            }
            if (Rezyser != "")
            {
                zapytanie += $"{tabela}.Rezyser LIKE '%" + Rezyser + "%' AND ";
            }
            if (Aktor != "")
            {
                zapytanie += $"{tabela}.RolaGlowna LIKE '%" + Aktor + "%' AND ";
            }
            if (Gatunek != "")
            {
                zapytanie += $"{tabela}.GatunekFilmowy = '" + Gatunek + "' AND ";
            }
            if (Opis != "")
            {
                zapytanie += $"{tabela}.OpisFabuly LIKE '%" + Opis + "%' AND ";
            }
            if (DataWydania != "  .  .")
            {
                zapytanie += $"{tabela}.DataWydania LIKE '%" + DataWydania + "%' AND ";
            }


            if (zapytanie == "WHERE ")
            {
                zapytanie = " AND";
            }
            int pocztek = (int)(zapytanie.Length) - 4;

            zapytanie = zapytanie.Remove(pocztek, 4);
            zapytanie += $" ORDER BY {tabela1}.ChecObejrzenia " + sortuj;
            return zapytanie;

        }

        public string ZapytaniaW(int id,string tabela= "FilmyDoObejrzenia")
        {
            string zapytania = $" WHERE {tabela}.IdFilmuDoObejrzenia=" + id;
            return zapytania;
        }
        
        public string ZapytaniaidFilmuDoObejrzeniia(int id, string tabela = "FilmyDoObejrzenia")
        {
            string zapytania = $"WHERE { tabela}.Id = {id} " ;
            return zapytania;
        }
        public void Usuwanie(int id, string nazwaTabeli = "FilmyDoObejrzenia")
        {
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"DELETE FROM  [{nazwaTabeli}] WHERE Id =" + id;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();

        }

        public void WyswietlanieTabeli(string zapytanie, string tabela , string tabela1, ListView lista = null)
        {

            lista.Clear();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            /*
             *  {tabela}.Id," +
                    $" {tabela1}.Tytul," +
                    $" {tabela1}.Rezyser," +
                    $" {tabela1}.RolaGlowna ," +
                    $"{tabela1}.GatunekFilmowy," +
                    $"{tabela}.ChecObejrzenia ," +
                    $"{tabela1}.DataWydania," +
                    $"{tabela1}.DataWydania," +
                    $"{tabela1}.CzasTrwania," +
                    $"{tabela1}.OpisFabuly " +
             */
            cmd.CommandType = CommandType.Text;
            string w = $" SELECT * FROM {tabela} INNER JOIN {tabela1} ON {tabela1}.Id = {tabela}.IdFilmuDoObejrzenia ";
            cmd.CommandText = w  + zapytanie;

            using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lista.View = View.Details;
                lista.Columns.Add("Id");
                lista.Columns.Add("Tytul                ");
                lista.Columns.Add("Rezyser              ");
                lista.Columns.Add("Rola Glowna          ");
                lista.Columns.Add("Gatunek Filmowy    ");

                lista.Columns.Add("Chec Obejrzenia");

                lista.Columns.Add("Data Wydania");
                lista.Columns.Add("Opis Fabuly              ");
                lista.Columns.Add("Czas Trwania");


                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                foreach (DataRow row in dt.Rows)
                {
                    
                    ListViewItem item1 = new ListViewItem(row[$"Id"].ToString());
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Tytul"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Rezyser"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"RolaGlowna"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"GatunekFilmowy"].ToString()));

                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"ChecObejrzenia"].ToString()));

                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"DataWydania"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"OpisFabuly"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"CzasTrwania"].ToString()));

                    lista.Items.Add(item1);


                }
            }


        }
    }


    }
