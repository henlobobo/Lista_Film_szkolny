﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OUsuwaniaFilmowW : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public OUsuwaniaFilmowW()
        {
            InitializeComponent();
        }

        private void OUsuwaniaFilmowW_Load(object sender, EventArgs e)
        {
            obsugaBazyDanych.WyswietlanieTabeli("","WszystkieFilmy", listView1);
        }

        private void btnusunFilm_Click(object sender, EventArgs e)
        {
            
          var result=  MessageBox.Show($"Czy napewno chcesz usunąc film o nazwie {nazwa} i reżyserze {rezyser}","Czy chcesz usunąć?",MessageBoxButtons.YesNo);
            if(result == DialogResult.Yes)
            {
                obsugaBazyDanych.Usuwanie(Id);
                //    listView1.SelectedIndexChanged;
                listView2.Clear();
                obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);

            }
            
        }
        

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);
            obsugaBazyDanych.WyswietlanieTabeli(obsugaBazyDanych.ZapytaniaUsuwania(id), "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[1].Text;
        }

    }
}
