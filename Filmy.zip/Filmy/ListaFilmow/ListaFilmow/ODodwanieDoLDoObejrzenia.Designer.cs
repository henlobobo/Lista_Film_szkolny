﻿
namespace ListaFilmow
{
    partial class ODodwanieDoLDoObejrzenia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ODodwanieDoLDoObejrzenia));
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnDodajFilmDoListy = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nChecZobaczenia = new System.Windows.Forms.NumericUpDown();
            this.btnDodajFilm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nChecZobaczenia)).BeginInit();
            this.SuspendLayout();
            // 
            // listView2
            // 
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(25, 83);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(732, 53);
            this.listView2.TabIndex = 3;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(25, 175);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(732, 193);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(544, 394);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(199, 31);
            this.btnZamknij.TabIndex = 48;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnDodajFilmDoListy
            // 
            this.btnDodajFilmDoListy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDodajFilmDoListy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilmDoListy.Location = new System.Drawing.Point(34, 394);
            this.btnDodajFilmDoListy.Name = "btnDodajFilmDoListy";
            this.btnDodajFilmDoListy.Size = new System.Drawing.Size(196, 31);
            this.btnDodajFilmDoListy.TabIndex = 47;
            this.btnDodajFilmDoListy.Text = "Dodaj  film do listy";
            this.btnDodajFilmDoListy.UseVisualStyleBackColor = false;
            this.btnDodajFilmDoListy.Click += new System.EventHandler(this.btnDodajFilmDoListy_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(53, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 49;
            this.label1.Text = "Chęć zobaczenia";
            // 
            // nChecZobaczenia
            // 
            this.nChecZobaczenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.nChecZobaczenia.Location = new System.Drawing.Point(476, 143);
            this.nChecZobaczenia.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nChecZobaczenia.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nChecZobaczenia.Name = "nChecZobaczenia";
            this.nChecZobaczenia.Size = new System.Drawing.Size(120, 23);
            this.nChecZobaczenia.TabIndex = 50;
            this.nChecZobaczenia.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnDodajFilm
            // 
            this.btnDodajFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDodajFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilm.Location = new System.Drawing.Point(305, 394);
            this.btnDodajFilm.Name = "btnDodajFilm";
            this.btnDodajFilm.Size = new System.Drawing.Size(163, 31);
            this.btnDodajFilm.TabIndex = 51;
            this.btnDodajFilm.Text = "Dodaj  film";
            this.btnDodajFilm.UseVisualStyleBackColor = false;
            this.btnDodajFilm.Click += new System.EventHandler(this.btnDodajFilm_Click);
            // 
            // ODodwanieDoLDoObejrzenia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDodajFilm);
            this.Controls.Add(this.nChecZobaczenia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnDodajFilmDoListy);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "ODodwanieDoLDoObejrzenia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodwanie Do Obejrzenia";
            this.Load += new System.EventHandler(this.ODodwanieDoLDoObejrzenia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nChecZobaczenia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnDodajFilmDoListy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nChecZobaczenia;
        private System.Windows.Forms.Button btnDodajFilm;
    }
}