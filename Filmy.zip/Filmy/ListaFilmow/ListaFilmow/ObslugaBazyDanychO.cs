﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Data;
using System.Windows.Forms;


namespace ListaFilmow
{
    class ObslugaBazyDanychO
    {
        public SQLiteCommand cmd = BazaDanych.polaczenie.CreateCommand();
        public int iloscRecordow(string nazwaTabeli)
        {
            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT MAX(id) FROM [{nazwaTabeli}]";
            var countResult = cmd.ExecuteScalar();
            int count = countResult is System.DBNull ? 0 : (int)(long)countResult;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return count + 1;
        }
        public void ModyfikacjaTabeli(int id,string pole, string nazwaPola, string nazwaTabeli = "FilmyObejrzene")
        {

            BazaDanych.polaczenie.Open();
            //     var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"UPDATE [{nazwaTabeli}] SET {nazwaPola} = '" + pole + "' WHERE Id=" + id;
            cmd.ExecuteNonQuery();


            BazaDanych.polaczenie.Close();


        }
        public bool CzyIstniej(int IdNFilmu)
        {
            bool czyIstniej;
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"SELECT COUNT(Id) FROM  [FilmyObejrzene] WHERE IdFilmuObejrzanego =" + IdNFilmu;
            var countResult = cmd.ExecuteScalar();
            if ((int)(long)countResult != 0)
            {
                //istnieje taki film
                czyIstniej = true;
            }
            else
            {
                czyIstniej = false;
            }
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return czyIstniej;
        }

        public int DoadnieFilmu(int IdFilmuObejrznego, int ocena, string opinia, string nazwaTabeli = "FilmyObejrzene")
        {

            int id = iloscRecordow(nazwaTabeli);

            BazaDanych.polaczenie.Open();
            // var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"INSERT INTO [{nazwaTabeli}] (Id,IdFilmuObejrzanego,Ocena,Opinia) VALUES" +
                $" ({id},{IdFilmuObejrznego}, '{ocena}','{opinia}')";
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();
            return id;

        }
        public string WyszukiwaniePoParametrach(string tytul, string rezyser, string aktor, string gatunek, string opis, string dataWydania,string opinia, string sortuj, string tabela, string tabela1)
        {
            string Tytul = tytul;
            string Rezyser = rezyser;
            string Aktor = aktor;
            string Gatunek = gatunek;
            string Opis = opis;
            string DataWydania = dataWydania;
            

            string zapytanie = "WHERE ";
            if (Tytul != "")
            {
                zapytanie += $"{tabela}.Tytul LIKE '%" + Tytul + "%' AND ";
            }
            if (Rezyser != "")
            {
                zapytanie += $"{tabela}.Rezyser LIKE '%" + Rezyser + "%' AND ";
            }
            if (Aktor != "")
            {
                zapytanie += $"{tabela}.RolaGlowna LIKE '%" + Aktor + "%' AND ";
            }
            if (Gatunek != "")
            {
                zapytanie += $"{tabela}.GatunekFilmowy = '" + Gatunek + "' AND ";
            }
            if (Opis != "")
            {
                zapytanie += $"{tabela}.OpisFabuly LIKE '%" + Opis + "%' AND ";
            }
            if (DataWydania != "  .  .")
            {
                zapytanie += $"{tabela}.DataWydania LIKE '%" + DataWydania + "%' AND ";
            }
            if (opinia != "")
            {
                zapytanie += $"{tabela1}.Opinia LIKE '%" + opinia + "%' AND ";
            }


            if (zapytanie == "WHERE ")
            {
                zapytanie = " AND";
            }
            int pocztek = (int)(zapytanie.Length) - 4;

            zapytanie = zapytanie.Remove(pocztek, 4);
            zapytanie += $" ORDER BY {tabela1}.Ocena " + sortuj;
            return zapytanie;

        }

        public string ZapytaniaW(int id, string tabela = "FilmyObejrzene")
        {
            string zapytania = $" WHERE {tabela}.IdFilmuObejrzanego=" + id;
            return zapytania;
        }

        public string ZapytaniaidFilmuDoObejrzeniia(int id, string tabela = "FilmyObejrzene")
        {
            string zapytania = $"WHERE { tabela}.Id = {id} ";
            return zapytania;
        }
        public void Usuwanie(int id, string nazwaTabeli = "FilmyObejrzene")
        {
            BazaDanych.polaczenie.Open();
            //  var cmd = BazaDanych.polaczenie.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = $"DELETE FROM  [{nazwaTabeli}] WHERE Id =" + id;
            cmd.ExecuteNonQuery();
            BazaDanych.polaczenie.Close();

        }

        public void WyswietlanieTabeli(string zapytanie, string tabela, string tabela1, ListView lista = null)
        {

            lista.Clear();
          
            cmd.CommandType = CommandType.Text;
            string w = $" SELECT * FROM {tabela} INNER JOIN {tabela1} ON {tabela1}.Id = {tabela}.IdFilmuObejrzanego ";
            cmd.CommandText = w + zapytanie;

            using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
            {
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lista.View = View.Details;

                lista.Columns.Add("Id");
                lista.Columns.Add("Tytul                ");
                lista.Columns.Add("Rezyser              ");
                lista.Columns.Add("Rola Glowna          ");
                lista.Columns.Add("Gatunek Filmowy ");

                lista.Columns.Add("Ocena");
                lista.Columns.Add("Opinia               ");

                lista.Columns.Add("Data Wydania");
                lista.Columns.Add("Opis Fabuly      ");
                lista.Columns.Add("Czas Trwania");

                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

                lista.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                foreach (DataRow row in dt.Rows)
                {

                    ListViewItem item1 = new ListViewItem(row[$"Id"].ToString());
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Tytul"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Rezyser"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"RolaGlowna"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"GatunekFilmowy"].ToString()));

                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Ocena"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"Opinia"].ToString()));

                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"DataWydania"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"OpisFabuly"].ToString()));
                    item1.SubItems.Add(new ListViewItem.ListViewSubItem(item1, row[$"CzasTrwania"].ToString()));

                    lista.Items.Add(item1);


                }
            }


        }
    }
}
