﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OUsuwaniaFilmyDO : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        ObslugaBazyDanychDO obsugaBazyDanychDO = new ObslugaBazyDanychDO();
        public OUsuwaniaFilmyDO()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);

            obsugaBazyDanychDO.WyswietlanieTabeli(obsugaBazyDanychDO.ZapytaniaidFilmuDoObejrzeniia(id, "FilmyDoObejrzenia"), "FilmyDoObejrzenia", "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[2].Text;

            
        }

        private void OUsuwaniaFilmyDO_Load(object sender, EventArgs e)
        {
            obsugaBazyDanychDO.WyswietlanieTabeli("", "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
        }

        private void btnusunFilm_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show($"Czy napewno chcesz usunąc film o nazwie {nazwa} i reżyserze {rezyser}", "Czy chcesz usunąć?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                listView2.Clear();
                obsugaBazyDanychDO.Usuwanie(Id, "FilmyDoObejrzenia");
            }
            obsugaBazyDanychDO.WyswietlanieTabeli("", "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
        }
    }
}
