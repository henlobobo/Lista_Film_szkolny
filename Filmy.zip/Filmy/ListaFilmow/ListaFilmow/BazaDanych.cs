﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SQLite;

namespace ListaFilmow
{
    class BazaDanych
    {
        private static SQLiteConnection _polaczenie;

        public static SQLiteConnection polaczenie
        {
            get
            {
                if (_polaczenie == null)
                {
                    var sciezka = Path.GetFullPath($@"{Environment.CurrentDirectory}\..\..\Film.sqlite");// zwaraca obecna sciezke do bazy danych 
                    _polaczenie = new SQLiteConnection($@"Data Source={sciezka};");


                    StworzTabele();
                }
                return _polaczenie;
            }
        }

        private static void StworzTabele()
        {
            try
            {
                _polaczenie.Open();

                var sprawdzCzyIstniejeTabela = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table' AND name='WszystkieFilmy';", _polaczenie);
                var czyIstnieje = sprawdzCzyIstniejeTabela.ExecuteScalar();

                if (czyIstnieje == null)
                {

                    var str = @"CREATE TABLE WszystkieFilmy (
    Id             INT          NOT NULL,
    Tytul          VARCHAR (50) NULL,
    Rezyser         VARCHAR (30) NULL,
    RolaGlowna          VARCHAR (30) NULL,
    GatunekFilmowy     VARCHAR (20) NULL,
    DataWydania    VARCHAR (15) NULL,
    OpisFabuly      TEXT NULL,
    CzasTrwania  VARCHAR (15) NULL,
    PRIMARY KEY ([Id] ASC)
);";

                    var stworzTabele = new SQLiteCommand(str, _polaczenie);
                    stworzTabele.ExecuteNonQuery();


                }



                sprawdzCzyIstniejeTabela = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table' AND name='FilmyDoObejrzenia';", _polaczenie);
                czyIstnieje = sprawdzCzyIstniejeTabela.ExecuteScalar();

                if (czyIstnieje == null)
                {

                    var str = @"CREATE TABLE FilmyDoObejrzenia (
         Id             INT          NOT NULL,
        IdFilmuDoObejrzenia          INT  NOT NULL,
        ChecObejrzenia         INT  NULL,
   
     PRIMARY KEY ([Id] ASC)
);";

                    var stworzTabele = new SQLiteCommand(str, _polaczenie);
                    stworzTabele.ExecuteNonQuery();

                }

                sprawdzCzyIstniejeTabela = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table' AND name='FilmyObejrzene';", _polaczenie);
                czyIstnieje = sprawdzCzyIstniejeTabela.ExecuteScalar();

                if (czyIstnieje == null)
                {

                    var str = @"CREATE TABLE FilmyObejrzene (
    Id             INT          NOT NULL,
    IdFilmuObejrzanego          INT  NOT NULL,
    Ocena         INT  NULL,
Opinia      TEXT NULL,
   
    PRIMARY KEY ([Id] ASC)
);";

                    var stworzTabele = new SQLiteCommand(str, _polaczenie);
                    stworzTabele.ExecuteNonQuery();

                }

            }
            finally
            {
                _polaczenie.Close();
            }

        }

    }
}
