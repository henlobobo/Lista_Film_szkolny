﻿
namespace ListaFilmow
{
    partial class OModyfikacjiFilmuO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OModyfikacjiFilmuO));
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.nOcena = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOpinia = new System.Windows.Forms.TextBox();
            this.lOcena = new System.Windows.Forms.Label();
            this.lOpina = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nOcena)).BeginInit();
            this.SuspendLayout();
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnZamknij.Location = new System.Drawing.Point(464, 527);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(267, 46);
            this.btnZamknij.TabIndex = 71;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(22, 527);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(267, 46);
            this.btnModyfikujFilm.TabIndex = 70;
            this.btnModyfikujFilm.Text = "Zapisz zmiany";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // nOcena
            // 
            this.nOcena.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.nOcena.Location = new System.Drawing.Point(488, 151);
            this.nOcena.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nOcena.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nOcena.Name = "nOcena";
            this.nOcena.Size = new System.Drawing.Size(120, 24);
            this.nOcena.TabIndex = 69;
            this.nOcena.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label1.Location = new System.Drawing.Point(65, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 18);
            this.label1.TabIndex = 68;
            this.label1.Text = "Ocena";
            // 
            // listView2
            // 
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(22, 191);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(732, 53);
            this.listView2.TabIndex = 67;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(22, 283);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(732, 193);
            this.listView1.TabIndex = 66;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label3.Location = new System.Drawing.Point(65, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 73;
            this.label3.Text = "Opinia";
            // 
            // txtOpinia
            // 
            this.txtOpinia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.txtOpinia.Location = new System.Drawing.Point(488, 102);
            this.txtOpinia.Name = "txtOpinia";
            this.txtOpinia.Size = new System.Drawing.Size(227, 24);
            this.txtOpinia.TabIndex = 75;
            // 
            // lOcena
            // 
            this.lOcena.AutoSize = true;
            this.lOcena.Location = new System.Drawing.Point(226, 157);
            this.lOcena.Name = "lOcena";
            this.lOcena.Size = new System.Drawing.Size(35, 13);
            this.lOcena.TabIndex = 72;
            this.lOcena.Text = "label2";
            // 
            // lOpina
            // 
            this.lOpina.AutoSize = true;
            this.lOpina.Location = new System.Drawing.Point(226, 114);
            this.lOpina.Name = "lOpina";
            this.lOpina.Size = new System.Drawing.Size(35, 13);
            this.lOpina.TabIndex = 74;
            this.lOpina.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label2.Location = new System.Drawing.Point(79, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(319, 18);
            this.label2.TabIndex = 76;
            this.label2.Text = "Wybierz film z listy, który chcesz modyfikować:";
            // 
            // OModyfikacjiFilmuO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 585);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOpinia);
            this.Controls.Add(this.lOpina);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lOcena);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.nOcena);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OModyfikacjiFilmuO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Okno Modyfikacji Filmu";
            this.Load += new System.EventHandler(this.OModyfikacjiFilmuO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nOcena)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.NumericUpDown nOcena;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOpinia;
        private System.Windows.Forms.Label lOcena;
        private System.Windows.Forms.Label lOpina;
        private System.Windows.Forms.Label label2;
    }
}