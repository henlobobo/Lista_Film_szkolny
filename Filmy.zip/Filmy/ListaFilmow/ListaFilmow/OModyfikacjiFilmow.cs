﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OModyfikacjiFilmow : Form
    {
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public OModyfikacjiFilmow()
        {
            InitializeComponent();
        }
        public void UstawPuste()
        {
            txtTytul.Text = "";
            txtRezyser.Text = "";
            txtAktor.Text = "";
            cmbGatunek.Text = "";
            txtOpis.Text = "";
            mtxtRokWydania.Text = "";
            mtxtCzasTrawania.Text = "";

        }
        private int Id;
        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            string Tytul = txtTytul.Text;
            string Rezyser = txtRezyser.Text;
            string Aktor = txtAktor.Text;
            string Gatunek = cmbGatunek.Text;
            string Opis = txtOpis.Text;
            string DataWydania = mtxtRokWydania.Text;
            string CzasTrwania = mtxtCzasTrawania.Text;

            obsugaBazyDanych.CoModyfikowac(Tytul,Rezyser,Aktor,Gatunek,Opis,DataWydania,CzasTrwania,Id, "WszystkieFilmy");
            UstawPuste();
            obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
        }

        private void OModyfikacjiFilmow_Load(object sender, EventArgs e)
        {
           obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy",listView1);
        }
       
        
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                return;
            }
            
            int id= Int32.Parse( listView1.SelectedItems[0].Text);
            lTytul.Text = listView1.SelectedItems[0].SubItems[1].Text;
            lRezyzser.Text = listView1.SelectedItems[0].SubItems[2].Text;
            lAktor.Text = listView1.SelectedItems[0].SubItems[3].Text;
            lGatunekFilmowy.Text = listView1.SelectedItems[0].SubItems[4].Text;
            lDataWydania.Text = listView1.SelectedItems[0].SubItems[5].Text;
            lOpis.Text = listView1.SelectedItems[0].SubItems[6].Text;
            lCzasTrwania.Text = listView1.SelectedItems[0].SubItems[7].Text;

            Id = id;
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
