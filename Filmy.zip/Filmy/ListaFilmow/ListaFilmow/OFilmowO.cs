﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OFilmowO : Form
    {
        ObslugaBazyDanychO obslugaBazyDanychO = new ObslugaBazyDanychO();
        public OFilmowO()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnWyswietl_Click(object sender, EventArgs e)
        {
            string opinia = txtOpinia.Text;
            string Tytul = textBox1.Text;
            string Rezyser = txtRezyser.Text;
            string Aktor = txtAktor.Text;
            string Gatunek = cmbGatunek.Text;
            string Opis = txtOpis.Text;
            string DataWydania = mtxtRokWydania.Text;
            string sortowanie;
            if (cmbOcena.Text == "")
            {
                cmbOcena.Text = "Ro";
            }
            if (cmbOcena.Text[0] == 'R')
            {
                sortowanie = "ASC";
            }
            else
            {
                sortowanie = "DESC";
            }
            string zapytania = obslugaBazyDanychO.WyszukiwaniePoParametrach(Tytul, Rezyser, Aktor, Gatunek, Opis, DataWydania,opinia, sortowanie, "WszystkieFilmy", "FilmyObejrzene");
            obslugaBazyDanychO.WyswietlanieTabeli(zapytania, "FilmyObejrzene", "WszystkieFilmy", listView1);

        }

        private void OFilmowO_Load(object sender, EventArgs e)
        {
            obslugaBazyDanychO.WyswietlanieTabeli("", "FilmyObejrzene", "WszystkieFilmy", listView1);
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            Form okno = new ODodawaniaFilmuLO();
            okno.Show();
            this.Close();
        }

        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            Form okno = new OModyfikacjiFilmuO();
            okno.Show();
            this.Close();

        }

        private void btnUsunFilm_Click(object sender, EventArgs e)
        {
            Form okno = new OUsuwaniaFlimuO();
            okno.Show();
            this.Close();
        }
    }
}
