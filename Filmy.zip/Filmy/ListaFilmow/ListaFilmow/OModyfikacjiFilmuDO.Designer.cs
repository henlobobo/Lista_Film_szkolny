﻿
namespace ListaFilmow
{
    partial class OModyfikacjiFilmuDO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nChecZobaczenia = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.lnChecObejrzenia = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nChecZobaczenia)).BeginInit();
            this.SuspendLayout();
            // 
            // nChecZobaczenia
            // 
            this.nChecZobaczenia.Location = new System.Drawing.Point(500, 97);
            this.nChecZobaczenia.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nChecZobaczenia.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nChecZobaczenia.Name = "nChecZobaczenia";
            this.nChecZobaczenia.Size = new System.Drawing.Size(120, 20);
            this.nChecZobaczenia.TabIndex = 54;
            this.nChecZobaczenia.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label1.Location = new System.Drawing.Point(77, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 18);
            this.label1.TabIndex = 53;
            this.label1.Text = "Chęć zobaczenia";
            // 
            // listView2
            // 
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(34, 137);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(732, 53);
            this.listView2.TabIndex = 52;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.SelectedIndexChanged += new System.EventHandler(this.listView2_SelectedIndexChanged);
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(34, 229);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(732, 193);
            this.listView1.TabIndex = 51;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnZamknij.Location = new System.Drawing.Point(476, 473);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(267, 53);
            this.btnZamknij.TabIndex = 64;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(34, 473);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(267, 53);
            this.btnModyfikujFilm.TabIndex = 63;
            this.btnModyfikujFilm.Text = "Zapisz zmiany";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // lnChecObejrzenia
            // 
            this.lnChecObejrzenia.AutoSize = true;
            this.lnChecObejrzenia.Location = new System.Drawing.Point(238, 99);
            this.lnChecObejrzenia.Name = "lnChecObejrzenia";
            this.lnChecObejrzenia.Size = new System.Drawing.Size(35, 13);
            this.lnChecObejrzenia.TabIndex = 65;
            this.lnChecObejrzenia.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.label2.Location = new System.Drawing.Point(31, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(319, 18);
            this.label2.TabIndex = 74;
            this.label2.Text = "Wybierz film z listy, który chcesz modyfikować:";
            // 
            // OModyfikacjiFilmuDO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 558);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lnChecObejrzenia);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.nChecZobaczenia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listView1);
            this.Name = "OModyfikacjiFilmuDO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "okno modyfikacji filmu";
            this.Load += new System.EventHandler(this.OModyfikacjiFilmuDO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nChecZobaczenia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nChecZobaczenia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.Label lnChecObejrzenia;
        private System.Windows.Forms.Label label2;
    }
}