﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class ODodawaniaFilmuLW : Form
    {
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public ODodawaniaFilmuLW()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            string Tytul = txtTytul.Text;
            string Rezyser = txtRezyser.Text;
            string Aktor = txtAktor.Text;
            string Gatunek = cmbGatunek.Text;
            string Opis = txtOpis.Text;
            string DataWydania = mtxtRokWydania.Text;
            string CzasTrwania = mtxtCzasTrawania.Text;
            if (obsugaBazyDanych.CzyIstniej(Tytul,Rezyser))
            {
                MessageBox.Show($"Film o nazwie:{Tytul} i reżyseri {Rezyser} jest już na liscie");
            }
            else
            {
                var w = obsugaBazyDanych.DoadnieRestauracji(Tytul, Rezyser, Aktor, Gatunek, Opis, DataWydania, CzasTrwania, "WszystkieFilmy");
            }
           
        
            txtTytul.Text = "";
            txtRezyser.Text = "";
            txtAktor.Text = "";
            cmbGatunek.Text = "";
            txtOpis.Text = "";
            mtxtRokWydania.Text = "";
            mtxtCzasTrawania.Text = "";
        }

        private void ODodawaniaFilmuLW_Load(object sender, EventArgs e)
        {

        }
    }
}
