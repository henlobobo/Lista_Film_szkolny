﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    
    public partial class ODodawaniaFilmuLO : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObslugaBazyDanychO obsugaBazyDanychO = new ObslugaBazyDanychO();
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public ODodawaniaFilmuLO()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);

            obsugaBazyDanychO.WyswietlanieTabeli(obsugaBazyDanychO.ZapytaniaW(id, "FilmyObejrzene"), "FilmyObejrzene", "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[1].Text;
            
        }

        private void ODodawaniaFilmuLO_Load(object sender, EventArgs e)
        {
            obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            Form okno = new ODodawaniaFilmuLW();
            okno.Show();
            this.Close();
            
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDodajFilmDoListy_Click(object sender, EventArgs e)
        {
            string opinia = txtOpinia.Text;
             int ocena = (int)nOcena.Value;
            if (obsugaBazyDanychO.CzyIstniej(Id))
            {
                MessageBox.Show($"Film o nazwie:{nazwa} i reżyseri {rezyser} jest już na liscie");
            }
            else
            {
                listView2.Clear();
                obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
                obsugaBazyDanychO.DoadnieFilmu(Id, ocena, opinia, "FilmyObejrzene");
            }
           
        }
    }
}
