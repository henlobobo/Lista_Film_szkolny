﻿
namespace ListaFilmow
{
    partial class OListyDoObejrzenia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OListyDoObejrzenia));
            this.cmbGatunek = new System.Windows.Forms.ComboBox();
            this.mtxtRokWydania = new System.Windows.Forms.MaskedTextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.txtAktor = new System.Windows.Forms.TextBox();
            this.txtRezyser = new System.Windows.Forms.TextBox();
            this.txtTytul = new System.Windows.Forms.TextBox();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnUsunFilm = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.btnDodajFilm = new System.Windows.Forms.Button();
            this.btnWyswietl = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbChecObejrzenia = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbGatunek
            // 
            this.cmbGatunek.FormattingEnabled = true;
            this.cmbGatunek.Items.AddRange(new object[] {
            "Horror",
            "Dramat",
            "Komedia",
            "Fantazy",
            "Przygodowa",
            "Romans",
            "Dokumentalny"});
            this.cmbGatunek.Location = new System.Drawing.Point(145, 166);
            this.cmbGatunek.Name = "cmbGatunek";
            this.cmbGatunek.Size = new System.Drawing.Size(570, 21);
            this.cmbGatunek.TabIndex = 37;
            // 
            // mtxtRokWydania
            // 
            this.mtxtRokWydania.Location = new System.Drawing.Point(145, 202);
            this.mtxtRokWydania.Mask = "00/00/0000";
            this.mtxtRokWydania.Name = "mtxtRokWydania";
            this.mtxtRokWydania.Size = new System.Drawing.Size(570, 20);
            this.mtxtRokWydania.TabIndex = 36;
            this.mtxtRokWydania.ValidatingType = typeof(System.DateTime);
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(145, 244);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(570, 20);
            this.txtOpis.TabIndex = 35;
            // 
            // txtAktor
            // 
            this.txtAktor.Location = new System.Drawing.Point(145, 134);
            this.txtAktor.Name = "txtAktor";
            this.txtAktor.Size = new System.Drawing.Size(570, 20);
            this.txtAktor.TabIndex = 34;
            // 
            // txtRezyser
            // 
            this.txtRezyser.Location = new System.Drawing.Point(145, 86);
            this.txtRezyser.Name = "txtRezyser";
            this.txtRezyser.Size = new System.Drawing.Size(570, 20);
            this.txtRezyser.TabIndex = 33;
            // 
            // txtTytul
            // 
            this.txtTytul.Location = new System.Drawing.Point(146, -20);
            this.txtTytul.Name = "txtTytul";
            this.txtTytul.Size = new System.Drawing.Size(570, 20);
            this.txtTytul.TabIndex = 32;
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(621, 590);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(165, 43);
            this.btnZamknij.TabIndex = 31;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnUsunFilm
            // 
            this.btnUsunFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnUsunFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnUsunFilm.Location = new System.Drawing.Point(418, 590);
            this.btnUsunFilm.Name = "btnUsunFilm";
            this.btnUsunFilm.Size = new System.Drawing.Size(165, 43);
            this.btnUsunFilm.TabIndex = 30;
            this.btnUsunFilm.Text = "Usuń film";
            this.btnUsunFilm.UseVisualStyleBackColor = false;
            this.btnUsunFilm.Click += new System.EventHandler(this.btnUsunFilm_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(219, 590);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(165, 43);
            this.btnModyfikujFilm.TabIndex = 29;
            this.btnModyfikujFilm.Text = "Modyfikuj film";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // btnDodajFilm
            // 
            this.btnDodajFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDodajFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnDodajFilm.Location = new System.Drawing.Point(12, 590);
            this.btnDodajFilm.Name = "btnDodajFilm";
            this.btnDodajFilm.Size = new System.Drawing.Size(165, 43);
            this.btnDodajFilm.TabIndex = 28;
            this.btnDodajFilm.Text = "Dodaj nowy film";
            this.btnDodajFilm.UseVisualStyleBackColor = false;
            this.btnDodajFilm.Click += new System.EventHandler(this.btnDodajFilm_Click);
            // 
            // btnWyswietl
            // 
            this.btnWyswietl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnWyswietl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnWyswietl.Location = new System.Drawing.Point(10, 311);
            this.btnWyswietl.Name = "btnWyswietl";
            this.btnWyswietl.Size = new System.Drawing.Size(777, 36);
            this.btnWyswietl.TabIndex = 27;
            this.btnWyswietl.Text = "Wyświetl wyniki";
            this.btnWyswietl.UseVisualStyleBackColor = false;
            this.btnWyswietl.Click += new System.EventHandler(this.btnWyswietl_Click);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.listView1.Location = new System.Drawing.Point(11, 354);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(775, 207);
            this.listView1.TabIndex = 26;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l6.Location = new System.Drawing.Point(24, 243);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(37, 17);
            this.l6.TabIndex = 25;
            this.l6.Text = "Opis";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l5.Location = new System.Drawing.Point(24, 201);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(93, 17);
            this.l5.TabIndex = 24;
            this.l5.Text = "Data wydania";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l4.Location = new System.Drawing.Point(24, 165);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(111, 17);
            this.l4.TabIndex = 23;
            this.l4.Text = "Gatunek filmowy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, -13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Tytuł";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l1.Location = new System.Drawing.Point(24, 93);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(60, 17);
            this.l1.TabIndex = 21;
            this.l1.Text = "Reżyser";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l2.Location = new System.Drawing.Point(24, 133);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(41, 17);
            this.l2.TabIndex = 20;
            this.l2.Text = "Aktor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, -54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Wyszukaj po:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(12, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 17);
            this.label2.TabIndex = 39;
            this.label2.Text = "Sortuj według chęci obejrzenia";
            // 
            // cmbChecObejrzenia
            // 
            this.cmbChecObejrzenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.cmbChecObejrzenia.FormattingEnabled = true;
            this.cmbChecObejrzenia.Items.AddRange(new object[] {
            "Rosnąco",
            "Malejąco"});
            this.cmbChecObejrzenia.Location = new System.Drawing.Point(219, 280);
            this.cmbChecObejrzenia.Name = "cmbChecObejrzenia";
            this.cmbChecObejrzenia.Size = new System.Drawing.Size(253, 25);
            this.cmbChecObejrzenia.TabIndex = 40;
            this.cmbChecObejrzenia.Text = "Rosnąco";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(145, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(570, 20);
            this.textBox1.TabIndex = 42;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(24, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 41;
            this.label3.Text = "Tytuł";
            // 
            // OListyDoObejrzenia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 657);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbChecObejrzenia);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbGatunek);
            this.Controls.Add(this.mtxtRokWydania);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtAktor);
            this.Controls.Add(this.txtRezyser);
            this.Controls.Add(this.txtTytul);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnUsunFilm);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.btnDodajFilm);
            this.Controls.Add(this.btnWyswietl);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.l6);
            this.Controls.Add(this.l5);
            this.Controls.Add(this.l4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OListyDoObejrzenia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista Do Obejrzenia";
            this.Load += new System.EventHandler(this.OListyDoObejrzenia_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbGatunek;
        private System.Windows.Forms.MaskedTextBox mtxtRokWydania;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.TextBox txtAktor;
        private System.Windows.Forms.TextBox txtRezyser;
        private System.Windows.Forms.TextBox txtTytul;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnUsunFilm;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.Button btnDodajFilm;
        private System.Windows.Forms.Button btnWyswietl;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbChecObejrzenia;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
    }
}