﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OModyfikacjiFilmuDO : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        ObslugaBazyDanychDO obsugaBazyDanychDO = new ObslugaBazyDanychDO();
        public OModyfikacjiFilmuDO()
        {
            InitializeComponent();
        }

        private void OModyfikacjiFilmuDO_Load(object sender, EventArgs e)
        {
            obsugaBazyDanychDO.WyswietlanieTabeli("", "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);
            
            obsugaBazyDanychDO.WyswietlanieTabeli(obsugaBazyDanychDO.ZapytaniaidFilmuDoObejrzeniia(id, "FilmyDoObejrzenia"), "FilmyDoObejrzenia", "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[2].Text;
          
            lnChecObejrzenia.Text = listView1.SelectedItems[0].SubItems[5].Text;
            decimal w = Convert.ToDecimal(lnChecObejrzenia.Text);
            nChecZobaczenia.Value = w;
        }

        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            int chceObejrzec = (int)nChecZobaczenia.Value;
            obsugaBazyDanychDO.ModyfikacjaTabeli(chceObejrzec.ToString(),Id, "ChecObejrzenia", "FilmyDoObejrzenia");
          //  MessageBox.Show($"Film o nazwie {nazwa} i reżyserze {rezyser} został zmodyfikowany");
            lnChecObejrzenia.Text = "";
            nChecZobaczenia.Value = 1;
            listView2.Clear();
            obsugaBazyDanychDO.WyswietlanieTabeli("", "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
          

        }
    }
}
