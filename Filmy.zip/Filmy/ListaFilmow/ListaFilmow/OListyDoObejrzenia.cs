﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class OListyDoObejrzenia : Form
    {
        ObslugaBazyDanychDO obslugaBazyDanychDO = new ObslugaBazyDanychDO();
        public OListyDoObejrzenia()
        {
            InitializeComponent();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            Form okno = new ODodwanieDoLDoObejrzenia();
            okno.Show();
            this.Close();
        }

        private void OListyDoObejrzenia_Load(object sender, EventArgs e)
        {
            obslugaBazyDanychDO.WyswietlanieTabeli("", "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
        }

        private void btnWyswietl_Click(object sender, EventArgs e)
        {
            string Tytul = textBox1.Text;
            string Rezyser = txtRezyser.Text;
            string Aktor = txtAktor.Text;
            string Gatunek = cmbGatunek.Text;
            string Opis = txtOpis.Text;
            string DataWydania = mtxtRokWydania.Text;
            string sortowanie;
            if (cmbChecObejrzenia.Text == "")
            {
                cmbChecObejrzenia.Text = "Ro";
            }
            if (cmbChecObejrzenia.Text[0]=='R'){
                sortowanie = "ASC";
            }
            else
            {
                sortowanie = "DESC";
            }
          string zapytania=  obslugaBazyDanychDO.WyszukiwaniePoParametrach(Tytul, Rezyser, Aktor, Gatunek, Opis, DataWydania, sortowanie, "WszystkieFilmy","FilmyDoObejrzenia");
            obslugaBazyDanychDO.WyswietlanieTabeli(zapytania, "FilmyDoObejrzenia", "WszystkieFilmy", listView1);
           
        }

        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            Form okno = new OModyfikacjiFilmuDO();
            okno.Show();
            this.Close();
        }

        private void btnUsunFilm_Click(object sender, EventArgs e)
        {
            OUsuwaniaFilmyDO okno = new OUsuwaniaFilmyDO();
            okno.Show();
            this.Close();
        }
    }
}
