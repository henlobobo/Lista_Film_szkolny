﻿
namespace ListaFilmow
{
    partial class OModyfikacjiFilmow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OModyfikacjiFilmow));
            this.btnZamknij = new System.Windows.Forms.Button();
            this.btnModyfikujFilm = new System.Windows.Forms.Button();
            this.cmbGatunek = new System.Windows.Forms.ComboBox();
            this.mtxtRokWydania = new System.Windows.Forms.MaskedTextBox();
            this.txtOpis = new System.Windows.Forms.TextBox();
            this.txtAktor = new System.Windows.Forms.TextBox();
            this.txtRezyser = new System.Windows.Forms.TextBox();
            this.txtTytul = new System.Windows.Forms.TextBox();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.mtxtCzasTrawania = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lOpis = new System.Windows.Forms.Label();
            this.lDataWydania = new System.Windows.Forms.Label();
            this.lGatunekFilmowy = new System.Windows.Forms.Label();
            this.lTytul = new System.Windows.Forms.Label();
            this.lRezyzser = new System.Windows.Forms.Label();
            this.lAktor = new System.Windows.Forms.Label();
            this.lCzasTrwania = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(477, 584);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(267, 44);
            this.btnZamknij.TabIndex = 62;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // btnModyfikujFilm
            // 
            this.btnModyfikujFilm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnModyfikujFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnModyfikujFilm.Location = new System.Drawing.Point(35, 584);
            this.btnModyfikujFilm.Name = "btnModyfikujFilm";
            this.btnModyfikujFilm.Size = new System.Drawing.Size(267, 44);
            this.btnModyfikujFilm.TabIndex = 61;
            this.btnModyfikujFilm.Text = "Zapisz zmiany";
            this.btnModyfikujFilm.UseVisualStyleBackColor = false;
            this.btnModyfikujFilm.Click += new System.EventHandler(this.btnModyfikujFilm_Click);
            // 
            // cmbGatunek
            // 
            this.cmbGatunek.FormattingEnabled = true;
            this.cmbGatunek.Items.AddRange(new object[] {
            "Horror",
            "Dramat",
            "Komedia",
            "Fantazy",
            "Przygodowa",
            "Romans",
            "Dokumentalny"});
            this.cmbGatunek.Location = new System.Drawing.Point(364, 182);
            this.cmbGatunek.Name = "cmbGatunek";
            this.cmbGatunek.Size = new System.Drawing.Size(380, 21);
            this.cmbGatunek.TabIndex = 60;
            // 
            // mtxtRokWydania
            // 
            this.mtxtRokWydania.Location = new System.Drawing.Point(364, 218);
            this.mtxtRokWydania.Mask = "00/00/0000";
            this.mtxtRokWydania.Name = "mtxtRokWydania";
            this.mtxtRokWydania.Size = new System.Drawing.Size(380, 20);
            this.mtxtRokWydania.TabIndex = 59;
            this.mtxtRokWydania.ValidatingType = typeof(System.DateTime);
            // 
            // txtOpis
            // 
            this.txtOpis.Location = new System.Drawing.Point(364, 257);
            this.txtOpis.Name = "txtOpis";
            this.txtOpis.Size = new System.Drawing.Size(380, 20);
            this.txtOpis.TabIndex = 58;
            // 
            // txtAktor
            // 
            this.txtAktor.Location = new System.Drawing.Point(364, 150);
            this.txtAktor.Name = "txtAktor";
            this.txtAktor.Size = new System.Drawing.Size(380, 20);
            this.txtAktor.TabIndex = 57;
            // 
            // txtRezyser
            // 
            this.txtRezyser.Location = new System.Drawing.Point(364, 107);
            this.txtRezyser.Name = "txtRezyser";
            this.txtRezyser.Size = new System.Drawing.Size(380, 20);
            this.txtRezyser.TabIndex = 56;
            // 
            // txtTytul
            // 
            this.txtTytul.Location = new System.Drawing.Point(364, 69);
            this.txtTytul.Name = "txtTytul";
            this.txtTytul.Size = new System.Drawing.Size(380, 20);
            this.txtTytul.TabIndex = 55;
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l6.Location = new System.Drawing.Point(44, 260);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(37, 17);
            this.l6.TabIndex = 54;
            this.l6.Text = "Opis";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l5.Location = new System.Drawing.Point(44, 218);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(93, 17);
            this.l5.TabIndex = 53;
            this.l5.Text = "Data wydania";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l4.Location = new System.Drawing.Point(44, 182);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(111, 17);
            this.l4.TabIndex = 52;
            this.l4.Text = "Gatunek filmowy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(44, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 17);
            this.label4.TabIndex = 51;
            this.label4.Text = "Tytuł";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l1.Location = new System.Drawing.Point(44, 110);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(60, 17);
            this.l1.TabIndex = 50;
            this.l1.Text = "Reżyser";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.l2.Location = new System.Drawing.Point(44, 150);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(41, 17);
            this.l2.TabIndex = 49;
            this.l2.Text = "Aktor";
            // 
            // mtxtCzasTrawania
            // 
            this.mtxtCzasTrawania.Location = new System.Drawing.Point(364, 289);
            this.mtxtCzasTrawania.Mask = "90:00";
            this.mtxtCzasTrawania.Name = "mtxtCzasTrawania";
            this.mtxtCzasTrawania.Size = new System.Drawing.Size(380, 20);
            this.mtxtCzasTrawania.TabIndex = 48;
            this.mtxtCzasTrawania.ValidatingType = typeof(System.DateTime);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(44, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 47;
            this.label1.Text = "Czas trwania";
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(35, 352);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(721, 210);
            this.listView1.TabIndex = 63;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // lOpis
            // 
            this.lOpis.AutoSize = true;
            this.lOpis.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lOpis.Location = new System.Drawing.Point(190, 260);
            this.lOpis.Name = "lOpis";
            this.lOpis.Size = new System.Drawing.Size(37, 17);
            this.lOpis.TabIndex = 70;
            this.lOpis.Text = "Opis";
            // 
            // lDataWydania
            // 
            this.lDataWydania.AutoSize = true;
            this.lDataWydania.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lDataWydania.Location = new System.Drawing.Point(190, 218);
            this.lDataWydania.Name = "lDataWydania";
            this.lDataWydania.Size = new System.Drawing.Size(93, 17);
            this.lDataWydania.TabIndex = 69;
            this.lDataWydania.Text = "Data wydania";
            // 
            // lGatunekFilmowy
            // 
            this.lGatunekFilmowy.AutoSize = true;
            this.lGatunekFilmowy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lGatunekFilmowy.Location = new System.Drawing.Point(190, 182);
            this.lGatunekFilmowy.Name = "lGatunekFilmowy";
            this.lGatunekFilmowy.Size = new System.Drawing.Size(111, 17);
            this.lGatunekFilmowy.TabIndex = 68;
            this.lGatunekFilmowy.Text = "Gatunek filmowy";
            // 
            // lTytul
            // 
            this.lTytul.AutoSize = true;
            this.lTytul.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lTytul.Location = new System.Drawing.Point(190, 69);
            this.lTytul.Name = "lTytul";
            this.lTytul.Size = new System.Drawing.Size(39, 17);
            this.lTytul.TabIndex = 67;
            this.lTytul.Text = "Tytuł";
            // 
            // lRezyzser
            // 
            this.lRezyzser.AutoSize = true;
            this.lRezyzser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lRezyzser.Location = new System.Drawing.Point(190, 110);
            this.lRezyzser.Name = "lRezyzser";
            this.lRezyzser.Size = new System.Drawing.Size(60, 17);
            this.lRezyzser.TabIndex = 66;
            this.lRezyzser.Text = "Reżyser";
            // 
            // lAktor
            // 
            this.lAktor.AutoSize = true;
            this.lAktor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lAktor.Location = new System.Drawing.Point(190, 150);
            this.lAktor.Name = "lAktor";
            this.lAktor.Size = new System.Drawing.Size(41, 17);
            this.lAktor.TabIndex = 65;
            this.lAktor.Text = "Aktor";
            // 
            // lCzasTrwania
            // 
            this.lCzasTrwania.AutoSize = true;
            this.lCzasTrwania.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lCzasTrwania.Location = new System.Drawing.Point(190, 289);
            this.lCzasTrwania.Name = "lCzasTrwania";
            this.lCzasTrwania.Size = new System.Drawing.Size(88, 17);
            this.lCzasTrwania.TabIndex = 64;
            this.lCzasTrwania.Text = "Czas trwania";
            // 
            // OModyfikacjiFilmow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(800, 640);
            this.Controls.Add(this.lOpis);
            this.Controls.Add(this.lDataWydania);
            this.Controls.Add(this.lGatunekFilmowy);
            this.Controls.Add(this.lTytul);
            this.Controls.Add(this.lRezyzser);
            this.Controls.Add(this.lAktor);
            this.Controls.Add(this.lCzasTrwania);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnModyfikujFilm);
            this.Controls.Add(this.cmbGatunek);
            this.Controls.Add(this.mtxtRokWydania);
            this.Controls.Add(this.txtOpis);
            this.Controls.Add(this.txtAktor);
            this.Controls.Add(this.txtRezyser);
            this.Controls.Add(this.txtTytul);
            this.Controls.Add(this.l6);
            this.Controls.Add(this.l5);
            this.Controls.Add(this.l4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.mtxtCzasTrawania);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OModyfikacjiFilmow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Okno Modyfikacji Filmow";
            this.Load += new System.EventHandler(this.OModyfikacjiFilmow_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.Button btnModyfikujFilm;
        private System.Windows.Forms.ComboBox cmbGatunek;
        private System.Windows.Forms.MaskedTextBox mtxtRokWydania;
        private System.Windows.Forms.TextBox txtOpis;
        private System.Windows.Forms.TextBox txtAktor;
        private System.Windows.Forms.TextBox txtRezyser;
        private System.Windows.Forms.TextBox txtTytul;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.MaskedTextBox mtxtCzasTrawania;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label lOpis;
        private System.Windows.Forms.Label lDataWydania;
        private System.Windows.Forms.Label lGatunekFilmowy;
        private System.Windows.Forms.Label lTytul;
        private System.Windows.Forms.Label lRezyzser;
        private System.Windows.Forms.Label lAktor;
        private System.Windows.Forms.Label lCzasTrwania;
    }
}