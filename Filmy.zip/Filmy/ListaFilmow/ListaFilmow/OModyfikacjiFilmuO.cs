﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{

    
    public partial class OModyfikacjiFilmuO : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        ObslugaBazyDanychO obsugaBazyDanychO = new ObslugaBazyDanychO();
        public OModyfikacjiFilmuO()
        {
            InitializeComponent();
        }

        private void OModyfikacjiFilmuO_Load(object sender, EventArgs e)
        {
            obsugaBazyDanychO.WyswietlanieTabeli("", "FilmyObejrzene", "WszystkieFilmy", listView1);
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);

            obsugaBazyDanychO.WyswietlanieTabeli(obsugaBazyDanychO.ZapytaniaidFilmuDoObejrzeniia(id, "FilmyObejrzene"), "FilmyObejrzene", "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[2].Text;

            lOpina.Text = listView1.SelectedItems[0].SubItems[6].Text;
            lOcena.Text = listView1.SelectedItems[0].SubItems[5].Text;
            nOcena.Value = Convert.ToDecimal(lOcena.Text);

        }

        private void btnModyfikujFilm_Click(object sender, EventArgs e)
        {
            int ocena = (int)nOcena.Value;
            if (ocena.ToString() !=lOcena.Text)
            {
                obsugaBazyDanychO.ModyfikacjaTabeli(Id, ocena.ToString(), "Ocena", "FilmyObejrzene");
            }

            string opinia = txtOpinia.Text;
            if (opinia != lOpina.Text&& opinia!="")
            {
                obsugaBazyDanychO.ModyfikacjaTabeli(Id, opinia, " Opinia", "FilmyObejrzene");
            }
          // 
         //   MessageBox.Show($"Film o nazwie {nazwa} i reżyserze {rezyser} został zmodyfikowany");
            lOpina.Text = "";
            nOcena.Value = 1;
            lOcena.Text = "";
            listView2.Clear();
            obsugaBazyDanychO.WyswietlanieTabeli("", "FilmyObejrzene", "WszystkieFilmy", listView1);
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
