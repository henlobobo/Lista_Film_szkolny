﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaFilmow
{
    public partial class ODodwanieDoLDoObejrzenia : Form
    {
        private int Id;
        private string nazwa;
        private string rezyser;
        ObslugaBazyDanychDO obsugaBazyDanychDO = new ObslugaBazyDanychDO();
        ObsugaBazyDanych obsugaBazyDanych = new ObsugaBazyDanych();
        public ODodwanieDoLDoObejrzenia()
        {
            InitializeComponent();
        }

        private void btnDodajFilmDoListy_Click(object sender, EventArgs e)
        {
            if (obsugaBazyDanychDO.CzyIstniej(Id))
            {
                MessageBox.Show($"Film o nazwie:{nazwa} i reżyseri {rezyser} jest już na liscie");
            }
            else
            {
                int checZobacznia = (int)nChecZobaczenia.Value;
                listView2.Clear();
                obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
                obsugaBazyDanychDO.DoadnieFilmu(Id, checZobacznia);
            }
            nChecZobaczenia.Value = 1;

        }
        

        private void ODodwanieDoLDoObejrzenia_Load(object sender, EventArgs e)
        {
            obsugaBazyDanych.WyswietlanieTabeli("", "WszystkieFilmy", listView1);
        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int id = Int32.Parse(listView1.SelectedItems[0].Text);
          
            obsugaBazyDanychDO.WyswietlanieTabeli(obsugaBazyDanychDO.ZapytaniaW(id, "FilmyDoObejrzenia"), "FilmyDoObejrzenia", "WszystkieFilmy", listView2);
            Id = id;
            nazwa = listView1.SelectedItems[0].SubItems[1].Text;
            rezyser = listView1.SelectedItems[0].SubItems[1].Text;
           
        }

        private void btnDodajFilm_Click(object sender, EventArgs e)
        {
            Form okno = new ODodawaniaFilmuLW();
            okno.Show();
            this.Close();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
