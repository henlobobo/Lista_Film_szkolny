﻿
namespace ListaFilmow
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnWszysktichFilmow = new System.Windows.Forms.Button();
            this.btnListaFilmowDObejrzenia = new System.Windows.Forms.Button();
            this.ListaFilmowObejrzanych = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnWszysktichFilmow
            // 
            this.btnWszysktichFilmow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnWszysktichFilmow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnWszysktichFilmow.Location = new System.Drawing.Point(68, 36);
            this.btnWszysktichFilmow.Name = "btnWszysktichFilmow";
            this.btnWszysktichFilmow.Size = new System.Drawing.Size(275, 66);
            this.btnWszysktichFilmow.TabIndex = 0;
            this.btnWszysktichFilmow.Text = "Lista wszystkich filmów";
            this.btnWszysktichFilmow.UseVisualStyleBackColor = false;
            this.btnWszysktichFilmow.Click += new System.EventHandler(this.btnWszysktichFilmow_Click);
            // 
            // btnListaFilmowDObejrzenia
            // 
            this.btnListaFilmowDObejrzenia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnListaFilmowDObejrzenia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnListaFilmowDObejrzenia.Location = new System.Drawing.Point(68, 128);
            this.btnListaFilmowDObejrzenia.Name = "btnListaFilmowDObejrzenia";
            this.btnListaFilmowDObejrzenia.Size = new System.Drawing.Size(275, 66);
            this.btnListaFilmowDObejrzenia.TabIndex = 1;
            this.btnListaFilmowDObejrzenia.Text = "Lista filmów do obejrzenia";
            this.btnListaFilmowDObejrzenia.UseVisualStyleBackColor = false;
            this.btnListaFilmowDObejrzenia.Click += new System.EventHandler(this.btnListaFilmowDObejrzenia_Click);
            // 
            // ListaFilmowObejrzanych
            // 
            this.ListaFilmowObejrzanych.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ListaFilmowObejrzanych.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.ListaFilmowObejrzanych.Location = new System.Drawing.Point(68, 218);
            this.ListaFilmowObejrzanych.Name = "ListaFilmowObejrzanych";
            this.ListaFilmowObejrzanych.Size = new System.Drawing.Size(275, 66);
            this.ListaFilmowObejrzanych.TabIndex = 2;
            this.ListaFilmowObejrzanych.Text = "Lista filmów obejrzanych";
            this.ListaFilmowObejrzanych.UseVisualStyleBackColor = false;
            this.ListaFilmowObejrzanych.Click += new System.EventHandler(this.ListaFilmowObejrzanych_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnZamknij.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btnZamknij.Location = new System.Drawing.Point(68, 308);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(275, 35);
            this.btnZamknij.TabIndex = 47;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = false;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(405, 374);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.ListaFilmowObejrzanych);
            this.Controls.Add(this.btnListaFilmowDObejrzenia);
            this.Controls.Add(this.btnWszysktichFilmow);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(421, 413);
            this.MinimumSize = new System.Drawing.Size(421, 413);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Moje filmy";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnWszysktichFilmow;
        private System.Windows.Forms.Button btnListaFilmowDObejrzenia;
        private System.Windows.Forms.Button ListaFilmowObejrzanych;
        private System.Windows.Forms.Button btnZamknij;
    }
}

